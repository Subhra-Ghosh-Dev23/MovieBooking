let showTime = [{
    id:1,
    showTime: "2:00PM"
  },
  {
    id:2,
    showTime: "4:00PM"
  },
  {
    id:3,
    showTime: "6:45PM"
  },
  {
    id:4,
    showTime: "10:00PM"
  }
]

export default showTime;